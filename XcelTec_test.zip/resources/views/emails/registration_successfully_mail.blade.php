<div>
    <p>Hello,</p>
    <br>
    <p>Thank you for signing up with Create My Contract!</p>
    <p>Your account can be accessed <a href="{{$login}}">Click Here!</a></p>
    <p>If you have any issues with your account, please contact us at  <a href="mailto:support@createmycontract.com">support@createmycontract.com</a></p>
    <br>
    <p>Best wishes</p>
    <p>The CMC Team</p>
    <br>
</div>
