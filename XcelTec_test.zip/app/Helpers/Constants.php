<?php
/*** USER PROFILE PICTURE FOLDER PATH CODE START ***/
define("DOCUMENT_FILE", 'uploads/document/');
define('PHPWORD_BASE_DIR', realpath(__DIR__));
define ("DATE_FORMAT","d F Y");




				
				


?>